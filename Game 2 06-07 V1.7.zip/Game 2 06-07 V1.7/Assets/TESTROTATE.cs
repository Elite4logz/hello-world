﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class TESTROTATE : MonoBehaviour {

	
	private void FixedUpdate()
	{
		transform.Rotate(new Vector3(0, 0, -50) * Time.deltaTime);
		transform.position += new Vector3(1, 0, 0) * Time.deltaTime;

		Debug.Log(transform.position);
	}
}
